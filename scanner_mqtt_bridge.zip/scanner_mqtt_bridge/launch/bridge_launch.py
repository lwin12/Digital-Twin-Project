from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            'mqtt_broker',
            default_value='192.168.137.1',
            description='MQTT broker IP address'
        ),
        DeclareLaunchArgument(
            'mqtt_port',
            default_value='1883',
            description='MQTT broker port'
        ),
        Node(
            package='scanner_mqtt_bridge',
            executable='mqtt_bridge',
            output='screen',
            parameters=[{
                'mqtt_broker': LaunchConfiguration('mqtt_broker'),
                'mqtt_port': LaunchConfiguration('mqtt_port'),
            }],
        ),
    ])
