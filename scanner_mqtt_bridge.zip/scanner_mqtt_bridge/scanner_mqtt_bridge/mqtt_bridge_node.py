"""
MQTT ↔ ROS2 Bridge Node for the 3D Scanner System.

Bridges all MQTT topics to ROS2 topics and vice versa.

MQTT → ROS2 (monitoring):
    host/startpreview     → /scanner/host/startpreview
    host/startcapture     → /scanner/host/startcapture
    host/capture_now      → /scanner/host/capture_now
    host/focus_now        → /scanner/host/focus_now
    host/objectname       → /scanner/host/objectname
    host/cam_zoom         → /scanner/host/cam_zoom
    host/status           → /scanner/host/status
    Pi_1/capture_done     → /scanner/pi_1/capture_done
    Pi_2/capture_done     → /scanner/pi_2/capture_done
    Pi_3/capture_done     → /scanner/pi_3/capture_done
    Pi_1/Turn             → /scanner/pi_1/turn
    Pi_1/CaptureTime      → /scanner/pi_1/capture_time

ROS2 → MQTT (control):
    /scanner/cmd/startpreview  → host/startpreview
    /scanner/cmd/startcapture  → host/startcapture
    /scanner/cmd/objectname    → host/objectname
    /scanner/cmd/cam_zoom      → host/cam_zoom
    /scanner/cmd/status        → host/status
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

import threading
import paho.mqtt.client as mqtt


class MqttBridgeNode(Node):

    def __init__(self):
        super().__init__('mqtt_bridge')

        # ---- Parameters ----
        self.declare_parameter('mqtt_broker', '192.168.137.1')
        self.declare_parameter('mqtt_port', 1883)

        self.broker = self.get_parameter('mqtt_broker').value
        self.port = self.get_parameter('mqtt_port').value

        # ---- MQTT → ROS2 mapping ----
        # Maps MQTT topics to ROS2 topic names
        self.mqtt_to_ros = {
            'host/startpreview':  '/scanner/host/startpreview',
            'host/startcapture':  '/scanner/host/startcapture',
            'host/capture_now':   '/scanner/host/capture_now',
            'host/focus_now':     '/scanner/host/focus_now',
            'host/objectname':    '/scanner/host/objectname',
            'host/cam_zoom':      '/scanner/host/cam_zoom',
            'host/status':        '/scanner/host/status',
            'Pi_1/capture_done':  '/scanner/pi_1/capture_done',
            'Pi_2/capture_done':  '/scanner/pi_2/capture_done',
            'Pi_3/capture_done':  '/scanner/pi_3/capture_done',
            'Pi_1/Turn':          '/scanner/pi_1/turn',
            'Pi_1/CaptureTime':   '/scanner/pi_1/capture_time',
        }

        # ---- ROS2 → MQTT mapping (control) ----
        self.ros_to_mqtt = {
            '/scanner/cmd/startpreview':  'host/startpreview',
            '/scanner/cmd/startcapture':  'host/startcapture',
            '/scanner/cmd/objectname':    'host/objectname',
            '/scanner/cmd/cam_zoom':      'host/cam_zoom',
            '/scanner/cmd/status':        'host/status',
        }

        # ---- Create ROS2 publishers (MQTT → ROS2) ----
        self.ros_publishers = {}
        for mqtt_topic, ros_topic in self.mqtt_to_ros.items():
            self.ros_publishers[mqtt_topic] = self.create_publisher(
                String, ros_topic, 10
            )
            self.get_logger().info(f'Publisher: {mqtt_topic} → {ros_topic}')

        # ---- Create ROS2 subscribers (ROS2 → MQTT) ----
        self.ros_subscribers = {}
        for ros_topic, mqtt_topic in self.ros_to_mqtt.items():
            self.ros_subscribers[ros_topic] = self.create_subscription(
                String,
                ros_topic,
                lambda msg, mt=mqtt_topic: self.ros_to_mqtt_callback(msg, mt),
                10
            )
            self.get_logger().info(f'Subscriber: {ros_topic} → {mqtt_topic}')

        # ---- MQTT Client Setup ----
        self.mqtt_client = mqtt.Client(
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
            client_id='ROS2Bridge'
        )
        self.mqtt_client.on_connect = self.on_mqtt_connect
        self.mqtt_client.on_message = self.on_mqtt_message
        self.mqtt_client.on_disconnect = self.on_mqtt_disconnect

        # Connect in a separate thread
        self.mqtt_thread = threading.Thread(target=self.mqtt_connect_loop, daemon=True)
        self.mqtt_thread.start()

        self.get_logger().info(
            f'MQTT Bridge started — broker: {self.broker}:{self.port}'
        )

    # =====================================================================
    # MQTT Callbacks
    # =====================================================================

    def mqtt_connect_loop(self):
        """Keep trying to connect to the MQTT broker."""
        while rclpy.ok():
            try:
                self.get_logger().info(
                    f'Connecting to MQTT broker at {self.broker}:{self.port}...'
                )
                self.mqtt_client.connect(self.broker, self.port)
                self.mqtt_client.loop_forever()
            except Exception as e:
                self.get_logger().warn(f'MQTT connection failed: {e}')
                self.get_logger().info('Retrying in 3 seconds...')
                import time
                time.sleep(3)

    def on_mqtt_connect(self, client, userdata, flags, rc, properties=None):
        if rc == 0:
            self.get_logger().info('Connected to MQTT broker')
            # Subscribe to all MQTT topics
            for mqtt_topic in self.mqtt_to_ros:
                client.subscribe(mqtt_topic)
                self.get_logger().info(f'  Subscribed to MQTT: {mqtt_topic}')
        else:
            self.get_logger().error(f'MQTT connection failed (rc={rc})')

    def on_mqtt_message(self, client, userdata, msg):
        """Forward MQTT messages to ROS2 topics."""
        mqtt_topic = msg.topic
        payload = msg.payload.decode().strip()

        if mqtt_topic in self.ros_publishers:
            ros_msg = String()
            ros_msg.data = payload
            self.ros_publishers[mqtt_topic].publish(ros_msg)
            self.get_logger().debug(
                f'MQTT → ROS2: {mqtt_topic} = "{payload}"'
            )

    def on_mqtt_disconnect(self, client, userdata, rc, properties=None, reasonCode=None):
        self.get_logger().warn(f'Disconnected from MQTT broker (rc={rc})')

    # =====================================================================
    # ROS2 → MQTT Callback
    # =====================================================================

    def ros_to_mqtt_callback(self, msg, mqtt_topic):
        """Forward ROS2 messages to MQTT topics."""
        if self.mqtt_client.is_connected():
            self.mqtt_client.publish(mqtt_topic, msg.data)
            self.get_logger().debug(
                f'ROS2 → MQTT: {mqtt_topic} = "{msg.data}"'
            )
        else:
            self.get_logger().warn(
                f'Cannot publish to MQTT — not connected'
            )

    # =====================================================================
    # Cleanup
    # =====================================================================

    def destroy_node(self):
        self.get_logger().info('Shutting down MQTT bridge...')
        self.mqtt_client.disconnect()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = MqttBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
